#!R
#Rscript to integrate SVs, APS, conservative, gencode and non coding elements to form the cwas data frame

library("optparse")

option_list = list(
        make_option(c("-r","--rdata"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("-f","--filter_SVID"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("-o","--output"), type="character", default=NULL, help="permutation_round", metavar="character")

 );


opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

load(opt$rdata)

if(length(colnames(sv_key)[which(colnames(sv_key)=='X.chr')])>0){
        colnames(sv_key)[which(colnames(sv_key)=='X.chr')] = 'X.chrom'
}

svid=read.table(opt$filter_SVID)
sv_key = sv_key[sv_key$name%in%svid[,1],]
save(sv_key, file = opt$output)


