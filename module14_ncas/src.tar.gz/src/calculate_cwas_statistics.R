#!R
#script to calculate cwas scores

library("optparse")

option_list = list(
        make_option(c('-d', "--data"), type="character", default=NULL, help="pre computed cwas data to load", metavar="character"),
        make_option(c('-p', "--prefix"), type="character", default=NULL, help="prefix of output file", metavar="character"),
        make_option(c('-a', "--appendix"), type="character", default=NULL, help="appendix of output file", metavar="character"),
        make_option(c('-t', "--svtype"), type="character", default=NULL, help="type of SVs to process", metavar="character"),
        make_option(c('-g', "--genic"), type="character", default=NULL, help="whether to process genic, intergenic or all SVs", metavar="character")
 );

opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

calcu_sd_from_SVcounts<-function(sv_count){
        slope = -0.5087
        intersect = -0.3093
        y = slope * log10(sv_count) + intersect
        return(10^y)
}

#define list of conservative, gencode and non coding elements
conserv_list = c("X239prim_DHS_mamm","X239prim_DHS_prim","X239prim_footprint_mamm","X239prim_footprint_prim","X239prim_uce","UCE_481","UCNE","phastCons100way","phyloP100way","HAR","zooHAR","zooCHAR","zoonomia_actively_evolving","zoonomia_highly_conserved","zoonomia_primate_spec","zoonomia_TFBSs","constraint_z")


load(opt$data)
sv_key = sv_key[!sv_key$X.chrom%in%c('chrX','chrY'),]
sv_key = sv_key[sv_key$end - sv_key$start < 1000000,]
sv_key[grepl('DEL',sv_key$svtype),]$svtype='DEL'
colnames(sv_key) = gsub('.over_50perc_ovr','', colnames(sv_key))

gencode_list = colnames(sv_key)[sapply(colnames(sv_key), function(x){strsplit(as.character(x),'[.]')[[1]][1] == 'gencode'})]
nc_list = colnames(sv_key)[sapply(colnames(sv_key), function(x){strsplit(as.character(x),'[.]')[[1]][1] == 'nc' | strsplit(as.character(x),'[.]')[[1]][1] == 'noncoding'})]

out = data.frame('svtype'=0,'intergenc'=0,'gencode' = 0, 'noncoding'=0,'conserve' = 0,'genomic_context' = 0,'SV_count'=0,'APS.all_SVLEN'=0,'APS.uniq_SVLEN'=0)
out_nrow = 0

i = opt$svtype
if(i=="ALL"){tmp0=sv_key}
if(i=="INS_ALL"){
        tmp0 = sv_key[grepl("INS",sv_key$svtype),]
}
if(i!="ALL" & i!="INS_ALL"){
        tmp0 = sv_key[sv_key$svtype==i,]
}
tmp0 = tmp0[!is.na(tmp0$marginal_aps.all_SVLEN),]

j = opt$genic
if(j=='all'){
        tmp1 = tmp0
}
if(j=='intergenic'){
        tmp1 = tmp0[tmp0$PREDICTED_INTERGENIC=='intergenic',]
}
if(j=='noncoding'){
        tmp1 = tmp0[tmp0$PREDICTED_INTERGENIC!='coding',]
}

N_cutoff_upper = 8002

for(k in c(gencode_list)){
        tmp2 = tmp1[tmp1[,colnames(tmp1)==k]>0,]
        if(nrow(tmp2)>0){
                for(l in nc_list){
                        tmp3 = tmp2[tmp2[,colnames(tmp2)==l]>0,]
                        if(nrow(tmp3)>0){
                                for(m in c(conserv_list, 'conserve.any', 'anti_conserve.any', 'conserve.NA')){
                                        print(c(i,j,k,l,m))
                                        if(m=='constraint_z'){
                                                for(ka in unique(tmp0$constraint_z)){
                                                        tmp4 = tmp3[tmp3$constraint_z==ka,]
                                                        if(nrow(tmp4)>0){
                                                                conserve_name=ka
                                                                if(conserve_name==0){conserve_name = 'z_under_2'}
                                                                out_nrow = out_nrow+1
                                                                out[out_nrow,1] = i
                                                                out[out_nrow,2] = j
                                                                out[out_nrow,3] = k
                                                                out[out_nrow,4] = l
                                                                out[out_nrow,5] = conserve_name
                                                                out[out_nrow,6] = 'ALL'
                                                                out[out_nrow,7] = nrow(tmp4)
                                                                if(nrow(tmp4)>N_cutoff_upper){
                                                                        tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                                }
                                                                out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                                out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                        }
                                                }
                                        }
                                        if(m!='constraint_z'){
                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]>0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'ALL'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }

                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]==0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'no_ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'ALL'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }
                                        }

                                }
                        }
                }
        }

        tmp2 = tmp1[tmp1$genomic_context=='SR' &  tmp1[,colnames(tmp1)==k]>0,]
        if(nrow(tmp2)>0){
                for(l in nc_list){
                        tmp3 = tmp2[tmp2[,colnames(tmp2)==l]>0,]
                        if(nrow(tmp3)>0){
                                for(m in c(conserv_list, "conserve.any","anti_conserve.any", "conserve.NA")){
                                        if(m=='constraint_z'){
                                                for(ka in unique(tmp0$constraint_z)){
                                                        tmp4 = tmp3[tmp3$constraint_z==ka,]
                                                        if(nrow(tmp4)>0){
                                                                conserve_name=ka
                                                                if(conserve_name==0){conserve_name = 'z_under_2'}
                                                                out_nrow = out_nrow+1
                                                                out[out_nrow,1] = i
                                                                out[out_nrow,2] = j
                                                                out[out_nrow,3] = k
                                                                out[out_nrow,4] = l
                                                                out[out_nrow,5] = conserve_name
                                                                out[out_nrow,6] = 'SR'
                                                                out[out_nrow,7] = nrow(tmp4)
                                                                if(nrow(tmp4)>N_cutoff_upper){
                                                                        tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                                }
                                                                out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                                out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                        }
                                                }
                                        }
                                        if(m!='constraint_z'){
                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]>0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'SR'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }

                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]==0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'no_ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'SR'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }
                                        }

                                }
                        }
                }
        }

        tmp2 = tmp1[tmp1$genomic_context=='SD' &  tmp1[,colnames(tmp1)==k]>0,]
        if(nrow(tmp2)>0){
                for(l in nc_list){
                        tmp3 = tmp2[tmp2[,colnames(tmp2)==l]>0,]
                        if(nrow(tmp3)>0){
                                for(m in c(conserv_list, 'conserve.any', 'anti_conserve.any', 'conserve.NA')){
                                        if(m=='constraint_z'){
                                                for(ka in unique(tmp0$constraint_z)){
                                                        tmp4 = tmp3[tmp3$constraint_z==ka,]
                                                        if(nrow(tmp4)>0){
                                                                conserve_name=ka
                                                                if(conserve_name==0){conserve_name = 'z_under_2'}
                                                                out_nrow = out_nrow+1
                                                                out[out_nrow,1] = i
                                                                out[out_nrow,2] = j
                                                                out[out_nrow,3] = k
                                                                out[out_nrow,4] = l
                                                                out[out_nrow,5] = conserve_name
                                                                out[out_nrow,6] = 'SD'
                                                                out[out_nrow,7] = nrow(tmp4)
                                                                if(nrow(tmp4)>N_cutoff_upper){
                                                                        tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                                }
                                                                out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                                out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                        }
                                                }
                                        }
                                        if(m!='constraint_z'){
                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]>0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'SD'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }

                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]==0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'no_ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'SD'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }
                                        }

                                }
                        }
                }
        }

        tmp2 = tmp1[!tmp1$genomic_context%in%c('SD','SR') &  tmp1[,colnames(tmp1)==k]>0,]
        if(nrow(tmp2)>0){
                for(l in nc_list){
                        tmp3 = tmp2[tmp2[,colnames(tmp2)==l]>0,]
                        if(nrow(tmp3)>0){
                                for(m in c(conserv_list, 'conserve.any', 'anti_conserve.any', 'conserve.NA')){
                                        if(m=='constraint_z'){
                                                for(ka in unique(tmp0$constraint_z)){
                                                        tmp4 = tmp3[tmp3$constraint_z==ka,]
                                                        if(nrow(tmp4)>0){
                                                                conserve_name=ka
                                                                if(conserve_name==0){conserve_name = 'z_under_2'}
                                                                out_nrow = out_nrow+1
                                                                out[out_nrow,1] = i
                                                                out[out_nrow,2] = j
                                                                out[out_nrow,3] = k
                                                                out[out_nrow,4] = l
                                                                out[out_nrow,5] = conserve_name
                                                                out[out_nrow,6] = 'clean'
                                                                out[out_nrow,7] = nrow(tmp4)
                                                                if(nrow(tmp4)>N_cutoff_upper){
                                                                        tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                                }
                                                                out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                                out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                        }
                                                }
                                        }
                                        if(m!='constraint_z'){
                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]>0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'clean'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }

                                                tmp4 = tmp3[tmp3[,colnames(tmp3)==m]==0,]
                                                if(nrow(tmp4)>0){
                                                        conserve_name = paste(m,'no_ovr',sep='.')
                                                        out_nrow = out_nrow+1
                                                        out[out_nrow,1] = i
                                                        out[out_nrow,2] = j
                                                        out[out_nrow,3] = k
                                                        out[out_nrow,4] = l
                                                        out[out_nrow,5] = conserve_name
                                                        out[out_nrow,6] = 'clean'
                                                        out[out_nrow,7] = nrow(tmp4)
                                                        if(nrow(tmp4)>N_cutoff_upper){
                                                                tmp4 = tmp4[sample(1:nrow(tmp4),N_cutoff_upper),]
                                                        }
                                                        out[out_nrow,8] = mean(tmp4$marginal_aps.all_SVLEN)
                                                        out[out_nrow,9] = mean(tmp4$marginal_aps.uniq_SVLEN)
                                                }
                                        }

                                }
                        }
                }
        }
}



#calculate sd of APS
out[,ncol(out)+1] = sapply(out$SV_count, calcu_sd_from_SVcounts)
colnames(out)[ncol(out)] = 'APS.sd'
#calculate p value of APS
out[,ncol(out)+1]= apply(out[,c("APS.all_SVLEN", "APS.sd")], 1, function(x){pnorm(abs(x[1]),0,x[2], lower.tail = FALSE, log.p = TRUE)})
colnames(out)[ncol(out)] = 'log_pvalue.all_SVLEN'
out[,ncol(out)+1]= apply(out[,c("APS.uniq_SVLEN", "APS.sd")], 1, function(x){pnorm(x[1],0,x[2], lower.tail = FALSE, log.p = TRUE)})
colnames(out)[ncol(out)] = 'log_pvalue.uniq_SVLEN'
#write cwas statistics
print(paste("writing output: ", paste(opt$prefix,i,j,opt$appendix,sep='.')))
write.table(out, paste(opt$prefix,i,j,opt$appendix,sep='.'), quote=F, sep='\t', col.names=T, row.names=F)

