#!R
## Rscript to integrate annotations across conserved elements
library("optparse")

option_list = list(
        make_option(c("--sv_vs_DHS_mamm"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_DHS_prim"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_footprint_mamm"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_footprint_prim"), type="character", default=NULL, help="permutation_round", metavar="character"),

        make_option(c("--sv_vs_UCE"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_UCE_481"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_UCNE"), type="character", default=NULL, help="permutation_round", metavar="character"),

        make_option(c("--sv_vs_phastCons100way"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_phyloP100way"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_z_over_2"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_z_over_4"), type="character", default=NULL, help="permutation_round", metavar="character"),

        make_option(c("--sv_vs_HAR"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zooHAR"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zooCHAR"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zoonomia_actively_evolving"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zoonomia_highly_conserved"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zoonomia_primate_spec"), type="character", default=NULL, help="permutation_round", metavar="character"),
        make_option(c("--sv_vs_zoonomia_TFBSs"), type="character", default=NULL, help="permutation_round", metavar="character"),

        make_option(c("--output"), type="character", default=NULL, help="permutation_round", metavar="character")
 );

opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

print(paste('read in', opt$sv_vs_DHS_mamm, '...'))
d1=read.table(opt$sv_vs_DHS_mamm)
d1=d1[,c(4,ncol(d1))]
colnames(d1) = c('name','X239prim_DHS_mamm')

print(paste('read in', opt$sv_vs_DHS_prim, '...'))
d2=read.table(opt$sv_vs_DHS_prim)
d2=d2[,c(4,ncol(d2))]
colnames(d2) = c('name','X239prim_DHS_prim')
dat=merge(d1,  d2, by='name')

print(paste('read in', opt$sv_vs_footprint_mamm, '...'))
d3=read.table(opt$sv_vs_footprint_mamm)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','X239prim_footprint_mamm')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_footprint_prim, '...'))
d3=read.table(opt$sv_vs_footprint_prim)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','X239prim_footprint_prim')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_UCE, '...'))
d3=read.table(opt$sv_vs_UCE)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','X239prim_uce')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_UCE_481, '...'))
d3=read.table(opt$sv_vs_UCE_481)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','UCE_481')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_UCNE, '...'))
d3=read.table(opt$sv_vs_UCNE)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','UCNE')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_phastCons100way, '...'))
d3=read.table(opt$sv_vs_phastCons100way)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','phastCons100way')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_phyloP100way, '...'))
d3=read.table(opt$sv_vs_phyloP100way)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','phyloP100way')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_HAR, '...'))
d3=read.table(opt$sv_vs_HAR)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','HAR')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zooHAR, '...'))
d3=read.table(opt$sv_vs_zooHAR)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zooHAR')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zooCHAR, '...'))
d3=read.table(opt$sv_vs_zooCHAR)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zooCHAR')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zoonomia_actively_evolving, '...'))
d3=read.table(opt$sv_vs_zoonomia_actively_evolving)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zoonomia_actively_evolving')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zoonomia_highly_conserved, '...'))
d3=read.table(opt$sv_vs_zoonomia_highly_conserved)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zoonomia_highly_conserved')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zoonomia_primate_spec, '...'))
d3=read.table(opt$sv_vs_zoonomia_primate_spec)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zoonomia_primate_spec')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_zoonomia_TFBSs, '...'))
d3=read.table(opt$sv_vs_zoonomia_TFBSs)
d3=d3[,c(4,ncol(d3))]
colnames(d3) = c('name','zoonomia_TFBSs')
dat=merge(dat, d3, by='name')

print(paste('read in', opt$sv_vs_z_over_2, '...'))
d8=read.table(opt$sv_vs_z_over_2)
print(paste('read in', opt$sv_vs_z_over_4, '...'))
d9=read.table(opt$sv_vs_z_over_4)

print('merge zscores ...')
dat[,ncol(dat)+1] = 0
colnames(dat)[ncol(dat)] = 'constraint_z'
dat[dat$name%in%d8[d8[,ncol(d8)]>0, 4],]$constraint_z = 'z_over_2'
dat[dat$name%in%d9[d9[,ncol(d9)]>0, 4],]$constraint_z = 'z_over_4'

print('write integrated file ...')
write.table(dat, opt$output, quote=F, sep='\t', col.names=T, row.names=F)


