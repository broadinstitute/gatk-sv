#!R 
library("optparse")

option_list = list(
        make_option(c('-i', "--input"), type="character", default=NULL, help="input file", metavar="character"),
        make_option(c('-o', "--output"), type="character", default=NULL, help="output file", metavar="character"),
        make_option(c('-s', "--sample_info"), type="character", default=NULL, help="input file", metavar="character") );

opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

dat=read.table(opt$input, header=T, comment.char="", sep='\t')
sample=read.table(opt$sample_info, header=F)

x = sample[1,2]

tmp = dat[grepl(x,dat$sample),]
tmp[,ncol(tmp)+1] = sapply(tmp[,ncol(tmp)], function(x){length(strsplit(as.character(x),',')[[1]])})
colnames(tmp)[ncol(tmp)] = 'count_genes'
tmp$samples = x
out = tmp[tmp$count_genes==1,]
for(i in unique(tmp$count_genes)){
        if(i>1){
                print(i)
                for(j in c(1:i)){
                        tmp2 = tmp[tmp$count_genes==i,]
                        tmp2[,6] = sapply(tmp2[,6],function(x){strsplit(as.character(x),',')[[1]][j]})
                        out = rbind(out, tmp2)
             }
        }
}

for(x in sample[2:nrow(sample),2]){
        print(x)
        tmp = dat[grepl(x,dat$sample),]
        tmp[,ncol(tmp)+1] = sapply(tmp[,ncol(tmp)], function(x){length(strsplit(as.character(x),',')[[1]])})
        colnames(tmp)[ncol(tmp)] = 'count_genes'
        tmp$samples = x
        out2 = tmp[tmp$count_genes==1,]
        for(i in unique(tmp$count_genes)){
                if(i>1){
                        for(j in c(1:i)){
                                tmp2 = tmp[tmp$count_genes==i,]
                                tmp2[,6] = sapply(tmp2[,6],function(x){strsplit(as.character(x),',')[[1]][j]})
                                out2 = rbind(out2, tmp2)
                     }
                }
        }
        out = rbind(out,out2)
}
write.table(out, opt$output, quote=F, sep='\t', col.names=T, row.names=F)


