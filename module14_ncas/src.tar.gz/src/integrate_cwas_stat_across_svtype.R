#!R
#Rscript to integrate SVs, APS, conservative, gencode and non coding elements to form the cwas data frame

library("optparse")

option_list = list(
        make_option(c( "--del"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--dup"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--inv"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--cpx"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--ins"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--alu"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--line1"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--sva"), type="character", default=NULL, help="input ncas statistics", metavar="character"),
        make_option(c( "--output"), type="character", default=NULL, help="input ncas statistics", metavar="character")
 );

opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);


calcu_sd_from_SVcounts<-function(sv_count){
        slope = -0.5087
        intersect = -0.3093
        y = slope * log10(sv_count) + intersect
        return(10^y)
}


permu = opt$permu
del=read.table(opt$del, header=T)
dup=read.table(opt$dup, header=T)
inv=read.table(opt$inv, header=T)
cpx=read.table(opt$cpx, header=T)
ins=read.table(opt$ins, header=T)
alu=read.table(opt$alu, header=T)
l1 =read.table(opt$line1, header=T)
sva=read.table(opt$sva, header=T)
dat=merge(del[,c("svtype","intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], dup[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat, inv[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat, cpx[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat, ins[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat, alu[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat,  l1[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat=merge(dat, sva[,c("intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")], by=c("intergenc","gencode","noncoding","conserve","genomic_context"), all=T)
dat[is.na(dat)] = 0
dat[,ncol(dat)+1] = apply(dat[,which(grepl('SV_count',colnames(dat)))], 1, sum)
colnames(dat)[ncol(dat)] = 'SV_count'
dat[,ncol(dat)+1] = apply(dat[,sort(c(which(grepl('SV_count',colnames(dat))), which(grepl('APS.all_SVLEN',colnames(dat)))))], 1, function(x){x[1]*x[2]+x[3]*x[4]+x[5]*x[6]+x[7]*x[8]+x[9]*x[10]+x[11]*x[12]+x[13]*x[14]+x[15]*x[16]})
dat[,ncol(dat)+1] = dat[,ncol(dat)]/dat$SV_count
colnames(dat)[ncol(dat)] = 'APS.all_SVLEN'
dat[,ncol(dat)+1] = apply(dat[,sort(c(which(grepl('SV_count',colnames(dat))), which(grepl('APS.uniq_SVLEN',colnames(dat)))))], 1, function(x){x[1]*x[2]+x[3]*x[4]+x[5]*x[6]+x[7]*x[8]+x[9]*x[10]+x[11]*x[12]+x[13]*x[14]+x[15]*x[16]})
dat[,ncol(dat)+1] = dat[,ncol(dat)]/dat$SV_count
colnames(dat)[ncol(dat)] = 'APS.uniq_SVLEN'
dat2=dat[,c("svtype","intergenc","gencode","noncoding","conserve","genomic_context","SV_count","APS.all_SVLEN","APS.uniq_SVLEN")]
dat2[,ncol(dat2)+1] = sapply(dat2$SV_count, calcu_sd_from_SVcounts)
colnames(dat2)[ncol(dat2)] = 'APS.sd'
dat2$svtype='ALL'
write.table(dat2, opt$output, quote=F, sep='\t', col.names=T, row.names=F)


